# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):
    display = "Place holder"
    return HttpResponse(display)
def create(request):
    return redirect('/')
def show(request, number):
    display = "PlaceHOLDER {}".format(number)
    return HttpResponse(display)
def edit(request, number):
    display = "EDIT PLACEHOLDER {}".format(number)
    return HttpResponse(display)
def delete(request, number):
    return redirect('/')
